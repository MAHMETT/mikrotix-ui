export const GeneralConfig = Object.freeze({
    Brand: 'MikrotixUI',
});

export const FileConfig = Object.freeze({
    LogoUrl: 'assets/images/Logo.webp',
    BackgroundUrl: 'assets/images/Background.webp',
});
