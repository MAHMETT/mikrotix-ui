export const Config = {
    Brand: 'MikrotixUI',
};
