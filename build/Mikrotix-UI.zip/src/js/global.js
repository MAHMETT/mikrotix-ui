import { Config } from '../../config.js';

// DOM
(function () {
    ('use strict');

    const Component = {
        header: `
        <header role="banner" class="text-center mb-8">
                <div class="flex items-center justify-center mb-4 gap-3">
                    <div class="logo">
                        <img src="assets/images/Logo.webp" alt="Logo" />
                    </div>
                    <div class="text-left">
                        <h1 class="text-2xl font-bold text-white">
                            ${Config.Brand}
                        </h1>
                    </div>
                </div>
            </header>
      `,

        footer: `
            <footer role="contentInfo" class="text-center">
                <p class="text-white/60 text-xs">
                    ©
                    <span id="currentYear">
                    ${new Date().getFullYear()}
                    </span>
                    ${Config.Brand}. All rights reserved.
                </p>
            </footer>
      `,
    };

    // Brand
    function Brand() {
        const brand = Config.Brand || 'MikrotixUI';
        const current = document.title;

        if (!current) {
            document.title = brand;
            return;
        }

        if (!current.endsWith(' - ' + brand)) {
            document.title = current + ' - ' + brand;
        }
    }

    // Head
    function Head() {
        const metas = [
            { name: 'description', content: Config.Brand },
            { name: 'keywords', content: Config.Brand },
            { name: 'apple-mobile-web-app-capable', content: 'yes' },
            { name: 'mobile-web-app-capable', content: 'yes' },
        ];

        const defaultMetas = [
            { charset: 'UTF-8' },
            {
                name: 'viewport',
                content: 'width=device-width, initial-scale=1.0',
            },
            { 'http-equiv': 'X-UA-Compatible', content: 'IE=edge' },
        ];

        const links = [
            {
                rel: 'shortcut icon',
                type: 'image/x-icon',
                href: 'assets/favicon.ico',
            },
            { rel: 'stylesheet', href: 'src/css/global.css' },
        ];

        defaultMetas.forEach((attrs) => {
            const meta = document.createElement('meta');
            Object.entries(attrs).forEach(([key, value]) => {
                meta.setAttribute(key, value);
            });
            document.head.appendChild(meta);
        });

        metas.forEach(({ name, content }) => {
            const meta = document.createElement('meta');
            meta.setAttribute('name', name);
            meta.setAttribute('content', content);
            document.head.appendChild(meta);
        });

        links.forEach((attrs) => {
            const link = document.createElement('link');
            Object.entries(attrs).forEach(([key, value]) => {
                link.setAttribute(key, value);
            });
            document.head.appendChild(link);
        });
    }

    // Component Logo, Title, and Footer
    function HeaderFooter(targetId = 'app') {
        const target = document.getElementById(targetId);
        if (!target) {
            console.warn('Target element not found:', targetId);
            return;
        }

        // cari main di dalam target; jika tidak ada, buat
        let main = target.querySelector('main');
        if (!main) {
            main = document.createElement('main');
            main.id = 'main-content';
            target.appendChild(main);
        }

        const headerNode = document.createElement('div');
        headerNode.innerHTML = Component.header;
        target.insertBefore(headerNode.firstElementChild, main);

        const footerNode = document.createElement('div');
        footerNode.innerHTML = Component.footer;
        target.appendChild(footerNode.firstElementChild);
    }

    document.addEventListener('DOMContentLoaded', () => {
        Head();
        Brand();
        HeaderFooter('app');

        document.oncontextmenu = () => false;
    });
})();
